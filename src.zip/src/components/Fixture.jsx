import CompletedMatches from "./CompletedMatches";
import {
  useEffect,
  useMemo,
  useState,
} from "react";
import { supabase } from "../supabase";
import { compareFixturesBySchedule, sortFixturesBySchedule } from "../utils/fixtureOrder";
import { syncLeagueFixtureWithRetry } from "../utils/pendingFixtureSync";

const TURKISH_DAYS = [
  "Pazar",
  "Pazartesi",
  "Salı",
  "Çarşamba",
  "Perşembe",
  "Cuma",
  "Cumartesi",
];

export default function Fixture({
  fixtures = [],
  setFixtures,
}) {
  const [fixtureTab, setFixtureTab] = useState("upcoming");
  const [draftDates, setDraftDates] = useState({});
  const [scores, setScores] = useState(() => {
    try {
      const saved =
        localStorage.getItem("sscup-scores-v3");

      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [matchGoals, setMatchGoals] =
    useState(() => {
      try {
        const saved = localStorage.getItem(
          "sscup-match-goals-v3"
        );

        return saved
          ? JSON.parse(saved)
          : {};
      } catch {
        return {};
      }
    });


  function getCurrentElapsed(match) {
    const savedSeconds = Number(
      match.elapsedSeconds
    ) || 0;

    if (
      match.timerRunning !== true ||
      !match.timerStartedAt
    ) {
      return savedSeconds;
    }

    const startedAt = Number(
      match.timerStartedAt
    );

    if (!Number.isFinite(startedAt)) {
      return savedSeconds;
    }

    return (
      savedSeconds +
      Math.max(
        0,
        Math.floor(
          (Date.now() - startedAt) / 1000
        )
      )
    );
  }

  function formatMatchTime(totalSeconds) {
    const safeSeconds = Math.max(
      0,
      Number(totalSeconds) || 0
    );

    const minutes = Math.floor(
      safeSeconds / 60
    );
    const seconds = safeSeconds % 60;

    return `${String(minutes).padStart(
      2,
      "0"
    )}:${String(seconds).padStart(
      2,
      "0"
    )}`;
  }

  // Fikstürün buluttan yüklenmesi yalnız App.jsx tarafından yapılır.
  // Bu bileşenin ayrıca Supabase okuyup state yazması açılışta yarış durumuna
  // neden oluyordu: gerçek yerel skor bir an görünüp ardından eski bulut 0-0
  // değeriyle ezilebiliyordu. Fixture artık yalnız mevcut props verisini kullanır.

  const groupedFixtures = useMemo(() => {
    const groups = {};

    fixtures.forEach((match, index) => {
      const week = Number(match.week) || 1;

      if (!groups[week]) {
        groups[week] = [];
      }

      groups[week].push({
        match,
        index,
      });
    });

    return Object.keys(groups)
      .map(Number)
      .map((week) => ({
        week,
        // Gerçek fixture index/ID değişmez; yalnızca ekrandaki görünüm kronolojiktir.
        // Düzenleme ekranında maçların yeri sabit kalsın. Tarih değiştirirken
        // kartın başka sıraya sıçramaması için fixture sırasını koru.
        matches: [...groups[week]].sort((a, b) => a.index - b.index),
      }))
      // Haftalar düzenleme sırasında yer değiştirmesin.
      .sort((a, b) => a.week - b.week);
  }, [fixtures]);

  const sortedUpcomingFixtures = useMemo(() => {
    // Görsel sıralama için maçları önce gerçek state index'i ile paketle.
    // ID üzerinden tekrar index aramak, eski/tekrarlı ID'lerde yanlış maçı
    // düzenleyebiliyordu (ör. 1. maçtan tarih değiştirirken başka maça sıçrama).
    return fixtures
      .map((match, index) => ({ match, index }))
      .filter(({ match }) => match.played !== true);
  }, [fixtures]);

  const leagueTeams = useMemo(() => {
    const names = new Set();
    fixtures.forEach((match) => {
      if (match?.isKnockout === true) return;
      if (match?.home) names.add(String(match.home).trim());
      if (match?.away) names.add(String(match.away).trim());
    });
    return [...names].filter(Boolean).sort((a, b) => a.localeCompare(b, "tr"));
  }, [fixtures]);

  const upcomingByWeek = useMemo(() => {
    const groups = new Map();

    sortedUpcomingFixtures.forEach((item) => {
      const week = Number(item.match?.week) || 1;
      if (!groups.has(week)) groups.set(week, []);
      groups.get(week).push(item);
    });

    return [...groups.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([week, matches]) => {
        const weekTeams = new Set();
        fixtures.forEach((match) => {
          if (match?.isKnockout === true || (Number(match?.week) || 1) !== week) return;
          if (match?.home) weekTeams.add(String(match.home).trim());
          if (match?.away) weekTeams.add(String(match.away).trim());
        });

        const bayTeams = leagueTeams.filter((team) => !weekTeams.has(team));
        return { week, matches, bayTeams };
      });
  }, [sortedUpcomingFixtures, fixtures, leagueTeams]);

  function getMatchWeekPlanKey(match, index) {
    return String(match?.id ?? match?.knockoutKey ?? `${match?.home || ""}-${match?.away || ""}-${index}`);
  }

  function findDisjointMatchIndexes(matches, targetCount, excludedTeam = "") {
    const chosen = [];
    const usedTeams = new Set();

    function search(startIndex) {
      if (chosen.length === targetCount) return true;
      if (matches.length - startIndex < targetCount - chosen.length) return false;

      for (let index = startIndex; index < matches.length; index += 1) {
        const item = matches[index];
        const home = String(item.match?.home || "");
        const away = String(item.match?.away || "");

        if (!home || !away) continue;
        if (excludedTeam && (home === excludedTeam || away === excludedTeam)) continue;
        if (usedTeams.has(home) || usedTeams.has(away)) continue;

        chosen.push(index);
        usedTeams.add(home);
        usedTeams.add(away);

        if (search(index + 1)) return true;

        chosen.pop();
        usedTeams.delete(home);
        usedTeams.delete(away);
      }

      return false;
    }

    return search(0) ? chosen.map((index) => matches[index]) : null;
  }

  async function arrangeEightMatchesPerWeek() {
    const leagueItems = fixtures
      .map((match, index) => ({ match, index, key: getMatchWeekPlanKey(match, index) }))
      .filter(({ match }) => match?.isKnockout !== true);

    if (leagueItems.length === 0) {
      alert("Düzenlenecek lig fikstürü bulunamadı.");
      return;
    }

    const bayTeam = "Bayramdere Gençlik";
    const teamNames = new Set();
    leagueItems.forEach(({ match }) => {
      if (match.home) teamNames.add(match.home);
      if (match.away) teamNames.add(match.away);
    });

    const useBayRule = teamNames.has(bayTeam);
    const remaining = [...leagueItems];
    const assignments = new Map();
    let week = 1;

    while (remaining.length > 0) {
      const target = Math.min(8, remaining.length);
      let selected = findDisjointMatchIndexes(
        remaining,
        target,
        week === 1 && useBayRule ? bayTeam : ""
      );

      if (!selected && target === 8) {
        // Son haftalarda 8 maçlık tam eşleşme kalmadıysa o haftanın mümkün
        // olan en büyük tek-maç-per-team grubunu bul. İlk iki hafta ise
        // kullanıcı isteği gereği mutlaka 8 maç olmalıdır.
        if (week <= 2) {
          alert(
            `${week}. hafta için aynı takımın iki kez oynamadığı 8 maçlık güvenli dağılım bulunamadı.\n\n` +
            "Hiçbir eşleşme değiştirilmedi. Fikstür korunuyor."
          );
          return;
        }

        for (let size = Math.min(7, target); size >= 1 && !selected; size -= 1) {
          selected = findDisjointMatchIndexes(remaining, size, "");
        }
      }

      if (!selected || selected.length === 0) {
        alert("Haftalık dağılım güvenli şekilde oluşturulamadı. Fikstüre dokunulmadı.");
        return;
      }

      selected.forEach((item) => assignments.set(item.key, week));
      const selectedKeys = new Set(selected.map((item) => item.key));
      for (let index = remaining.length - 1; index >= 0; index -= 1) {
        if (selectedKeys.has(remaining[index].key)) remaining.splice(index, 1);
      }
      week += 1;
    }

    const firstWeek = leagueItems.filter((item) => assignments.get(item.key) === 1);
    const secondWeek = leagueItems.filter((item) => assignments.get(item.key) === 2);
    if (firstWeek.length !== 8 || secondWeek.length !== 8) {
      alert("1. ve 2. hafta 8'er maç olacak güvenli plan oluşturulamadı. Fikstüre dokunulmadı.");
      return;
    }

    if (useBayRule && firstWeek.some(({ match }) => match.home === bayTeam || match.away === bayTeam)) {
      alert("Bayramdere Gençlik 1. hafta BAY kuralı sağlanamadı. Fikstüre dokunulmadı.");
      return;
    }

    const confirmed = window.confirm(
      `Mevcut eşleşmeler KESİNLİKLE değişmeden yalnız hafta numaraları düzenlenecek.\n\n` +
      `1. Hafta: 8 maç${useBayRule ? " • Bayramdere Gençlik BAY" : ""}\n` +
      `2. Hafta: 8 maç\n` +
      `Her takım bir haftada en fazla 1 maç oynayacak.\n\nDevam edilsin mi?`
    );
    if (!confirmed) return;

    const originalWeeks = new Map(leagueItems.map((item) => [item.key, item.match.week]));
    const changedCloudItems = [];

    try {
      for (const item of leagueItems) {
        const nextWeek = assignments.get(item.key);
        if (!Number.isFinite(Number(item.match.id)) || Number(item.match.week) === Number(nextWeek)) continue;

        const { error } = await supabase
          .from("fixtures")
          .update({ week: nextWeek })
          .eq("id", Number(item.match.id));

        if (error) throw error;
        changedCloudItems.push(item);
      }
    } catch (error) {
      console.error("Hafta dağılımı kaydetme hatası:", error);

      // Bulutta kısmi değişiklik olduysa eski hafta değerlerini geri yükle.
      for (const item of changedCloudItems) {
        try {
          await supabase
            .from("fixtures")
            .update({ week: originalWeeks.get(item.key) })
            .eq("id", Number(item.match.id));
        } catch (rollbackError) {
          console.error("Hafta geri alma hatası:", rollbackError);
        }
      }

      alert("Haftalık plan kaydedilemedi. Mevcut fikstür korunmaya çalışıldı; hiçbir eşleşme silinmedi.");
      return;
    }

    // Haftaları oluşturduktan sonra maçları GERÇEK PROGRAM sırasına da bağla.
    // Her hafta 8 maç = iki maç günü x 4 saat (20:00, 21:00, 22:00, 23:00).
    // Mevcut tarih havuzunu kronolojik kullanır; eşleşmeler ve maç ID'leri değişmez.
    const scheduleTimes = ["20:00", "21:00", "22:00", "23:00"];
    const availableDates = [...new Set(
      leagueItems
        .map(({ match }) => match?.date)
        .filter(Boolean)
        .sort((a, b) => compareFixturesBySchedule({ date: a, time: "00:00" }, { date: b, time: "00:00" }))
    )];

    const neededDays = Math.ceil(leagueItems.length / 4);
    if (availableDates.length < neededDays) {
      alert(
        `8 maç/hafta düzeni için en az ${neededDays} ayrı maç tarihi gerekiyor. ` +
        `Şu an ${availableDates.length} tarih var. Tarihler eksik olduğu için fikstüre dokunulmadı.`
      );
      return;
    }

    const weekBuckets = new Map();
    leagueItems.forEach((item) => {
      const assignedWeek = assignments.get(item.key);
      if (!weekBuckets.has(assignedWeek)) weekBuckets.set(assignedWeek, []);
      weekBuckets.get(assignedWeek).push(item);
    });

    const slotByKey = new Map();
    let dateCursor = 0;
    [...weekBuckets.keys()].sort((a, b) => a - b).forEach((weekNo) => {
      const weekItems = weekBuckets.get(weekNo);
      weekItems.forEach((item, position) => {
        const dayOffset = Math.floor(position / 4);
        const timeOffset = position % 4;
        slotByKey.set(item.key, {
          week: weekNo,
          date: availableDates[dateCursor + dayOffset],
          time: scheduleTimes[timeOffset],
        });
      });
      dateCursor += Math.ceil(weekItems.length / 4);
    });

    const updatedFixtures = sortFixturesBySchedule(
      fixtures.map((match, index) => {
        if (match?.isKnockout === true) return match;
        const slot = slotByKey.get(getMatchWeekPlanKey(match, index));
        return slot ? { ...match, ...slot } : match;
      })
    );

    // Hafta + tarih + saat birlikte Supabase'e kaydedilir.
    try {
      for (const match of updatedFixtures) {
        if (match?.isKnockout === true || !Number.isFinite(Number(match?.id))) continue;
        const { error } = await supabase
          .from("fixtures")
          .update({ week: match.week, date: match.date || null, time: match.time || null })
          .eq("id", Number(match.id));
        if (error) throw error;
      }
    } catch (error) {
      console.error("Tarih/saat programı kaydetme hatası:", error);
      alert("Tarih/saat programı buluta kaydedilemedi. Sayfayı yenileyip tekrar deneyin.");
      return;
    }

    setFixtures(updatedFixtures);
    localStorage.setItem("sscup-fixtures", JSON.stringify(updatedFixtures));

    alert(
      `✅ Haftalık dağılım tamamlandı.\n\n` +
      `1. hafta: 8 maç${useBayRule ? " • Bayramdere Gençlik BAY" : ""}\n` +
      `2. hafta: 8 maç\n` +
      `Eşleşmeler, maç kimlikleri, skorlar ve fikstür sırası korunmuştur.`
    );
  }

  function getSquads() {
    try {
      const saved =
        localStorage.getItem(
          "sscup-squads"
        );

      return saved
        ? JSON.parse(saved)
        : {};
    } catch {
      return {};
    }
  }

  function getTeamSquad(teamName) {
    const squads = getSquads();
    const squad = squads[teamName];

    return Array.isArray(squad)
      ? squad
      : [];
  }

  function getGoalCount(value) {
    if (
      value === "" ||
      value === undefined ||
      value === null
    ) {
      return 0;
    }

    const number = Number(value);

    if (
      !Number.isInteger(number) ||
      number < 0
    ) {
      return 0;
    }

    return number;
  }

  function resizeGoalList(
    currentList,
    count
  ) {
    const list = Array.isArray(
      currentList
    )
      ? [...currentList]
      : [];

    if (list.length > count) {
      return list.slice(0, count);
    }

    while (list.length < count) {
      list.push(null);
    }

    return list;
  }

  function getDayFromDate(dateValue) {
    if (!dateValue) {
      return "";
    }

    const date = new Date(
      `${dateValue}T12:00:00`
    );

    if (Number.isNaN(date.getTime())) {
      return "";
    }

    return TURKISH_DAYS[date.getDay()];
  }

  function formatVisibleDate(dateValue) {
    if (!dateValue) {
      return "Tarih seçilmedi";
    }

    const date = new Date(
      `${dateValue}T12:00:00`
    );

    if (Number.isNaN(date.getTime())) {
      return dateValue;
    }

    return date.toLocaleDateString(
      "tr-TR",
      {
        day: "2-digit",
        month: "long",
        year: "numeric",
      }
    );
  }

  function getCalendarWeekKey(dateValue) {
    if (!dateValue) return "";

    const date = new Date(`${dateValue}T12:00:00`);
    if (Number.isNaN(date.getTime())) return "";

    const day = date.getDay();
    const diffToMonday = day === 0 ? -6 : 1 - day;
    const monday = new Date(date);
    monday.setDate(date.getDate() + diffToMonday);

    return [
      monday.getFullYear(),
      String(monday.getMonth() + 1).padStart(2, "0"),
      String(monday.getDate()).padStart(2, "0"),
    ].join("-");
  }

  function hasSameTeamInCalendarWeek(match, matchIndex, dateValue) {
    const weekKey = getCalendarWeekKey(dateValue);
    if (!weekKey) return false;

    return fixtures.some((otherMatch, otherIndex) => {
      if (otherIndex === matchIndex || !otherMatch?.date) return false;
      if (getCalendarWeekKey(otherMatch.date) !== weekKey) return false;

      return (
        otherMatch.home === match.home ||
        otherMatch.away === match.home ||
        otherMatch.home === match.away ||
        otherMatch.away === match.away
      );
    });
  }

  async function updateMatchDetail(
    index,
    field,
    value
  ) {
    const currentMatch = fixtures[index];

    // Aynı takıma aynı takvim haftasında ikinci maç verilirse engellemek yerine
    // yönetici onayıyla istisna tanı. Özellikle 5. haftadaki telafi/son maçlar için.
    if (field === "date" && value && hasSameTeamInCalendarWeek(currentMatch, index, value)) {
      const weekKey = getCalendarWeekKey(value);
      const conflictingTeams = [currentMatch.home, currentMatch.away].filter((teamName) =>
        fixtures.some((otherMatch, otherIndex) =>
          otherIndex !== index &&
          otherMatch?.date &&
          getCalendarWeekKey(otherMatch.date) === weekKey &&
          (otherMatch.home === teamName || otherMatch.away === teamName)
        )
      );
      const confirmed = window.confirm(
        `⚠️ ${conflictingTeams.join(" / ")} bu hafta zaten maç oynuyor.\n\n` +
        `Bu maçı aynı haftaya İSTİSNA olarak eklemek istiyor musunuz?`
      );
      if (!confirmed) return;
    }

    const runtimeUpdatedAt = new Date().toISOString();
    const updatedFixtures =
      fixtures.map(
        (fixture, fixtureIndex) => {
          if (fixtureIndex !== index) {
            return fixture;
          }

          if (field === "date") {
            return {
              ...fixture,
              date: value,
              day:
                getDayFromDate(value) ||
                fixture.day ||
                "",
            };
          }

          return {
            ...fixture,
            [field]: value,
          };
        }
      );

    // Önce yerel state + kalıcı yerel kayıt birlikte güncellensin.
    // Sadece setFixtures yapmak, App yeniden okuma/senkron yaptığında eski tarihi
    // geri getirebiliyordu. Tarih kaydında tek gerçek kaynak updatedFixtures olsun.
    setFixtures(updatedFixtures);
    localStorage.setItem("sscup-fixtures-v3", JSON.stringify(updatedFixtures));
    localStorage.setItem("sscup-fixtures", JSON.stringify(updatedFixtures));
    window.dispatchEvent(new Event("sscup-fixtures-updated"));
    window.dispatchEvent(new Event("sscup-group-fixtures-updated"));

    // Tarih/saat/saha dahil TÜM fikstür alanları merkezi güvenli kuyruğa yazılır.
    // Bu fonksiyon güncel maçı önce localStorage kuyruğuna alır, sonra Supabase'e
    // gönderir ve gerçekten satır döndüğünü doğrular. Ağ kesilirse kuyruk korunur.
    const selectedMatch = updatedFixtures[index];
    if (selectedMatch?.isKnockout !== true && selectedMatch?.id != null && selectedMatch?.id !== "") {
      const synced = await syncLeagueFixtureWithRetry(selectedMatch);
      if (!synced) {
        alert("Değişiklik bu cihazda kaydedildi. Buluta gönderim beklemede; internet gelince otomatik tekrar denenecek.");
      }
    }
  }

  async function updateScore(
    index,
    side,
    value
  ) {
    if (
      value !== "" &&
      Number(value) < 0
    ) {
      return;
    }

    const updatedScores = {
      ...scores,
      [index]: {
        ...scores[index],
        [side]: value,
      },
    };

    const homeIsEmpty =
      updatedScores[index]?.home === "" ||
      updatedScores[index]?.home ===
        undefined;

    const awayIsEmpty =
      updatedScores[index]?.away === "" ||
      updatedScores[index]?.away ===
        undefined;

    setScores(updatedScores);

    localStorage.setItem(
      "sscup-scores-v3",
      JSON.stringify(updatedScores)
    );

    if (homeIsEmpty || awayIsEmpty) {
      const updatedFixtures =
        fixtures.map(
          (
            fixture,
            fixtureIndex
          ) =>
            fixtureIndex === index
              ? {
                  ...fixture,
                  homeScore: null,
                  awayScore: null,
                  played: false,
                }
              : fixture
        );

      const updatedGoals = {
        ...matchGoals,
        [index]: {
          home: [],
          away: [],
        },
      };

      setFixtures(updatedFixtures);
      setMatchGoals(updatedGoals);

      localStorage.setItem(
        "sscup-fixtures",
        JSON.stringify(
          updatedFixtures
        )
      );

      localStorage.setItem(
        "sscup-match-goals-v3",
        JSON.stringify(updatedGoals)
      );

      rebuildGoalScorers(
        updatedGoals
      );

      return;
    }

    const homeGoalCount =
      getGoalCount(
        updatedScores[index]?.home
      );

    const awayGoalCount =
      getGoalCount(
        updatedScores[index]?.away
      );

    setMatchGoals((current) => {
      const updatedGoals = {
        ...current,
        [index]: {
          home: resizeGoalList(
            current[index]?.home,
            homeGoalCount
          ),
          away: resizeGoalList(
            current[index]?.away,
            awayGoalCount
          ),
        },
      };

      localStorage.setItem(
        "sscup-match-goals-v3",
        JSON.stringify(
          updatedGoals
        )
      );

      return updatedGoals;
    });
  }

  function selectGoalScorer(
    matchIndex,
    side,
    goalIndex,
    playerId,
    teamName
  ) {
    const squad =
      getTeamSquad(teamName);

    const player = squad.find(
      (item) =>
        String(item.id) ===
        String(playerId)
    );

    const scorer = player
      ? {
          playerId: player.id,
          name: player.name,
          shirtNumber:
            player.shirtNumber,
          team: teamName,
        }
      : null;

    setMatchGoals((current) => {
      const currentMatch =
        current[matchIndex] || {
          home: [],
          away: [],
        };

      const updatedSide = [
        ...(currentMatch[side] || []),
      ];

      updatedSide[goalIndex] =
        scorer;

      const updatedGoals = {
        ...current,
        [matchIndex]: {
          ...currentMatch,
          [side]: updatedSide,
        },
      };

      localStorage.setItem(
        "sscup-match-goals-v3",
        JSON.stringify(
          updatedGoals
        )
      );

      return updatedGoals;
    });
  }

  function allScorersSelected(
    list,
    goalCount
  ) {
    if (goalCount === 0) {
      return true;
    }

    if (
      !Array.isArray(list) ||
      list.length !== goalCount
    ) {
      return false;
    }

    return list.every(
      (scorer) =>
        scorer &&
        scorer.playerId &&
        scorer.name &&
        scorer.team
    );
  }

  function rebuildGoalScorers(
    allMatchGoals
  ) {
    const totals = {};

    Object.values(
      allMatchGoals
    ).forEach((match) => {
      const allScorers = [
        ...(match?.home || []),
        ...(match?.away || []),
      ];

      allScorers.forEach(
        (scorer) => {
          if (
            !scorer?.playerId ||
            !scorer?.team
          ) {
            return;
          }

          const key =
            `${scorer.team}-${scorer.playerId}`;

          if (!totals[key]) {
            totals[key] = {
              id: key,
              playerId:
                scorer.playerId,
              name: scorer.name,
              team: scorer.team,
              shirtNumber:
                scorer.shirtNumber,
              goals: 0,
            };
          }

          totals[key].goals += 1;
        }
      );
    });

    const goalScorers =
      Object.values(totals);

    localStorage.setItem(
      "sscup-goals",
      JSON.stringify(goalScorers)
    );

    window.dispatchEvent(
      new CustomEvent(
        "sscup-goals-updated",
        {
          detail: goalScorers,
        }
      )
    );
  }

  function getMatchCenterKey(match, index = 0) {
    return String(match?.id ?? `${match?.home || ""}|${match?.away || ""}|${match?.week || ""}|${index}`);
  }

  async function toggleLiveMatch(index) {
    const selectedMatch = fixtures[index];

    if (selectedMatch.played === true) {
      alert("Oynanmış bir maç Maç Merkezi'ne alınamaz.");
      return;
    }

    const selectedKey = getMatchCenterKey(selectedMatch, index);
    const activeKey = localStorage.getItem("sscup-match-center-active") || "";
    const shouldSelect = activeKey !== selectedKey;

    const updatedFixtures = fixtures.map((fixture, fixtureIndex) => {
      const fixtureKey = getMatchCenterKey(fixture, fixtureIndex);

      if (fixtureIndex === index) {
        return {
          ...fixture,
          // Maç Merkezi'ne almak da geri çıkarmak da fikstür sırasını değiştirmez.
          // Geri çekilen maç normal bekleyen maç durumuna tamamen döner.
          live: false,
          matchPhase: "waiting",
          elapsedSeconds: 0,
          timerRunning: false,
          timerStartedAt: null,
        };
      }

      // Başka bir maçı merkeze alırken gerçek başlamamış eski hazırlık maçlarını canlı bırakma.
      if (fixture.matchPhase === "waiting") {
        return {
          ...fixture,
          live: false,
          timerRunning: false,
          timerStartedAt: null,
        };
      }

      return fixture;
    });

    if (shouldSelect) {
      localStorage.setItem("sscup-match-center-active", selectedKey);
    } else {
      localStorage.removeItem("sscup-match-center-active");
    }

    setFixtures(updatedFixtures);
    localStorage.setItem("sscup-fixtures", JSON.stringify(updatedFixtures));

    // Maç Merkezi hazırlığı bulutta CANLI sayılmasın. İnternet kısa süre kesilirse
    // bu bekleyen durum kuyruğa alınır ve bağlantı gelince otomatik tamamlanır.
    const resetMatch = updatedFixtures[index];
    if (resetMatch?.isKnockout !== true) {
      await syncLeagueFixtureWithRetry(resetMatch);
    }
  }

  function toggleTimer(index) {
    const updatedFixtures = fixtures.map(
      (fixture, fixtureIndex) => {
        if (fixtureIndex !== index) {
          return fixture;
        }

        if (fixture.timerRunning === true) {
          return {
            ...fixture,
            elapsedSeconds:
              getCurrentElapsed(fixture),
            timerRunning: false,
            timerStartedAt: null,
          };
        }

        return {
          ...fixture,
          timerRunning: true,
          timerStartedAt: Date.now(),
        };
      }
    );

    setFixtures(updatedFixtures);

    localStorage.setItem(
      "sscup-fixtures",
      JSON.stringify(updatedFixtures)
    );
  }

  async function saveMatch(index, finishMatch = false) {
    const match = fixtures[index];
    const score = scores[index];

    if (
      score?.home === "" ||
      score?.home === undefined ||
      score?.away === "" ||
      score?.away === undefined
    ) {
      alert(
        "İki takımın da skorunu giriniz."
      );

      return;
    }

    const homeScore = Number(
      score.home
    );

    const awayScore = Number(
      score.away
    );

    if (
      !Number.isInteger(homeScore) ||
      !Number.isInteger(awayScore) ||
      homeScore < 0 ||
      awayScore < 0
    ) {
      alert(
        "Skorlar 0 veya daha büyük tam sayı olmalıdır."
      );

      return;
    }

    const homeSquad =
      getTeamSquad(match.home);

    const awaySquad =
      getTeamSquad(match.away);

    if (
      homeScore > 0 &&
      homeSquad.length === 0
    ) {
      alert(
        `${match.home} takımının kadrosu bulunamadı. Önce Kadro Yönetimi bölümünden oyuncu ekleyin.`
      );

      return;
    }

    if (
      awayScore > 0 &&
      awaySquad.length === 0
    ) {
      alert(
        `${match.away} takımının kadrosu bulunamadı. Önce Kadro Yönetimi bölümünden oyuncu ekleyin.`
      );

      return;
    }

    const selectedGoals =
      matchGoals[index] || {
        home: [],
        away: [],
      };

    if (
      finishMatch &&
      !allScorersSelected(
        selectedGoals.home,
        homeScore
      )
    ) {
      alert(
        `${match.home} takımının ${homeScore} golü için bütün golcüleri seçiniz.`
      );

      return;
    }

    if (
      finishMatch &&
      !allScorersSelected(
        selectedGoals.away,
        awayScore
      )
    ) {
      alert(
        `${match.away} takımının ${awayScore} golü için bütün golcüleri seçiniz.`
      );

      return;
    }

    if (finishMatch) {
      const confirmed = window.confirm(
        `${match.home} - ${match.away} maçını bitirmek istiyor musunuz?`
      );

      if (!confirmed) {
        return;
      }
    }

    const currentElapsed = getCurrentElapsed(match);

    const updatedFixtures =
      fixtures.map(
        (
          fixture,
          fixtureIndex
        ) =>
          fixtureIndex === index
            ? {
                ...fixture,
                homeScore,
                awayScore,
                played: finishMatch
                  ? true
                  : fixture.played === true,
                live: finishMatch
                  ? false
                  : fixture.live === true,
                elapsedSeconds: finishMatch
                  ? currentElapsed
                  : fixture.elapsedSeconds,
                timerRunning: finishMatch
                  ? false
                  : fixture.timerRunning === true,
                timerStartedAt: finishMatch
                  ? null
                  : fixture.timerStartedAt,
                runtimeUpdatedAt,
              }
            : fixture
      );

    setFixtures(updatedFixtures);

    localStorage.setItem("sscup-fixtures-v3", JSON.stringify(updatedFixtures));
    localStorage.setItem("sscup-fixtures", JSON.stringify(updatedFixtures));

    // Lig maçları fixtures tablosuna, eleme maçları app_state tablosuna kaydedilir.
    if (match.isKnockout === true) {
      const { data: stateRow, error: readError } = await supabase
        .from("app_state")
        .select("value")
        .eq("id", "knockout")
        .maybeSingle();

      if (readError) {
        console.error("Eleme verisi okunamadı:", readError);
        alert(readError.message);
        return;
      }

      const value = stateRow?.value && typeof stateRow.value === "object"
        ? { ...stateRow.value }
        : {};
      const cloudMatch = {
        ...match,
        homeScore,
        awayScore,
        played: finishMatch,
        live: finishMatch ? false : match.live === true,
      };
      const [stage, rawIndex] = String(match.knockoutKey || "").split("-");
      const knockoutIndex = Number(rawIndex || 0);

      if (stage === "quarter") {
        const quarter = Array.isArray(value.quarter) ? [...value.quarter] : [];
        quarter[knockoutIndex] = { ...(quarter[knockoutIndex] || {}), ...cloudMatch };
        value.quarter = quarter;
      } else if (stage === "semi") {
        const semi = Array.isArray(value.semi) ? [...value.semi] : [];
        semi[knockoutIndex] = { ...(semi[knockoutIndex] || {}), ...cloudMatch };
        value.semi = semi;
      } else if (match.knockoutKey === "final-0") {
        value.finalMatch = { ...(value.finalMatch || {}), ...cloudMatch };
      } else if (match.knockoutKey === "third-place-0") {
        value.thirdPlace = { ...(value.thirdPlace || {}), ...cloudMatch };
      }

      const { error } = await supabase
        .from("app_state")
        .upsert({ id: "knockout", value, updated_at: new Date().toISOString() });

      if (error) {
        console.error("Eleme verisi kaydedilemedi:", error);
        alert(error.message);
        return;
      }
    } else {
      const cloudId = match?.id;
      if (cloudId === null || cloudId === undefined || cloudId === "") {
        alert("Lig maçı kimliği geçersiz.");
        return;
      }

      const { error } = await supabase
        .from("fixtures")
        .update({
          home_score: homeScore,
          away_score: awayScore,
          played: finishMatch,
        })
        .eq("id", cloudId);

      if (error) {
        console.error("SUPABASE HATA:", error);
        alert(error.message);
        return;
      }
    }


    const updatedMatchGoals = {
      ...matchGoals,
      [index]: {
        home: resizeGoalList(
          selectedGoals.home,
          homeScore
        ),
        away: resizeGoalList(
          selectedGoals.away,
          awayScore
        ),
      },
    };

    setMatchGoals(
      updatedMatchGoals
    );

    localStorage.setItem(
      "sscup-match-goals-v3",
      JSON.stringify(
        updatedMatchGoals
      )
    );

    rebuildGoalScorers(
      updatedMatchGoals
    );

    alert(
      finishMatch
        ? "Maç tamamlandı. Sonuç, puan durumu ve gol krallığı güncellendi."
        : "Skor ve golcüler kaydedildi. Maç canlı olarak devam ediyor."
    );
  }

  function renderGoalSelectors(
    match,
    matchIndex,
    side
  ) {
    const teamName =
      side === "home"
        ? match.home
        : match.away;

    const scoreValue =
      side === "home"
        ? scores[matchIndex]?.home
        : scores[matchIndex]?.away;

    const goalCount =
      getGoalCount(scoreValue);

    if (goalCount === 0) {
      return null;
    }

    const squad =
      getTeamSquad(teamName);

    if (squad.length === 0) {
      return (
        <p>
          <b>
            ⚠️ {teamName} takımının
            kadrosu bulunamadı.
          </b>
        </p>
      );
    }

    const selectedScorers =
      matchGoals[matchIndex]?.[
        side
      ] || [];

    return (
      <div
        style={{
          marginTop: "15px",
          padding: "12px",
          border:
            "1px solid #ddd",
          borderRadius: "8px",
        }}
      >
        <b>
          ⚽ {teamName} Golcüleri
        </b>

        {Array.from({
          length: goalCount,
        }).map((_, goalIndex) => (
          <div
            key={goalIndex}
            style={{
              marginTop: "10px",
            }}
          >
            <label>
              Gol {goalIndex + 1}:{" "}
            </label>

            <select
              value={
                selectedScorers[
                  goalIndex
                ]?.playerId || ""
              }
              onChange={(event) =>
                selectGoalScorer(
                  matchIndex,
                  side,
                  goalIndex,
                  event.target.value,
                  teamName
                )
              }
            >
              <option value="">
                Gol atan oyuncuyu seçiniz
              </option>

              {squad.map(
                (player) => (
                  <option
                    key={player.id}
                    value={player.id}
                  >
                    #
                    {
                      player.shirtNumber
                    }{" "}
                    {player.name}
                  </option>
                )
              )}
            </select>
          </div>
        ))}
      </div>
    );
  }

  function renderMatch(
    match,
    index
  ) {
    const fieldValue =
      match.field ||
      match.venue ||
      "Saha 1";

    return (
      <li
        key={
          match.id ||
          `${match.home}-${match.away}-${index}`
        }
        style={{
          marginBottom: "20px",
          padding: "15px",
          border:
            "1px solid #ddd",
          borderRadius: "10px",
        }}
      >
        <strong>
          Maç {match.matchNo || index + 1}:{" "}
          {match.home} - {match.away}
          {match.week ? ` • ${match.week}. Hafta` : ""}
        </strong>

        <div
          style={{
            marginTop: "12px",
            padding: "12px",
            borderRadius: "8px",
            border:
              "1px solid #777",
          }}
        >
          <p
            style={{
              marginTop: 0,
              marginBottom: "12px",
            }}
          >
            📅{" "}
            <b>
              {formatVisibleDate(
                match.date
              )}
            </b>
            {" • "}
            {match.day ||
              getDayFromDate(
                match.date
              ) ||
              "Gün belirtilmedi"}
            {" • "}
            🕒{" "}
            {match.time ||
              "Saat belirtilmedi"}
            {" • "}
            📍 {fieldValue}
          </p>

          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            <label>
              Tarih
              <br />

              <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                <input
                  type="date"
                  value={draftDates[getMatchWeekPlanKey(match, index)] ?? match.date ?? ""}
                  onChange={(event) => {
                    const key = getMatchWeekPlanKey(match, index);
                    setDraftDates((current) => ({ ...current, [key]: event.target.value }));
                  }}
                />
                <button
                  type="button"
                  onClick={async () => {
                    const key = getMatchWeekPlanKey(match, index);
                    const nextDate = draftDates[key] ?? match.date ?? "";
                    if (nextDate === (match.date || "")) return;
                    await updateMatchDetail(index, "date", nextDate);
                    setDraftDates((current) => {
                      const next = { ...current };
                      delete next[key];
                      return next;
                    });
                  }}
                  style={{ whiteSpace: "nowrap" }}
                >
                  Tarihi Kaydet
                </button>
              </div>
            </label>

            <label>
              Saat
              <br />

              <input
                type="time"
                value={
                  match.time || ""
                }
                onChange={(event) =>
                  updateMatchDetail(
                    index,
                    "time",
                    event.target.value
                  )
                }
              />
            </label>

            <label>
              Saha
              <br />

              <input
                type="text"
                value={fieldValue}
                onChange={(event) =>
                  updateMatchDetail(
                    index,
                    "field",
                    event.target.value
                  )
                }
              />
            </label>
          </div>
        </div>

        <button
          type="button"
          style={{
            marginTop: "15px",
            marginBottom: "5px",
          }}
          onClick={() =>
            toggleLiveMatch(index)
          }
        >
          {(localStorage.getItem("sscup-match-center-active") || "") === getMatchCenterKey(match, index)
            ? "❌ Maç Merkezinden Çıkar"
            : "🏟️ Maç Merkezine Al"}
        </button>

        {match.live === true && (match.matchPhase || "waiting") !== "waiting" && (
          <div
            style={{
              marginTop: "10px",
              padding: "12px",
              border: "1px solid #777",
              borderRadius: "8px",
            }}
          >
            <p style={{ margin: 0 }}>
              <b>🔴 Bu maç şu anda canlı.</b>
            </p>

            <p
              style={{
                marginTop: "10px",
                marginBottom: "10px",
                fontSize: "24px",
                fontWeight: "bold",
              }}
            >
              ⏱ {formatMatchTime(
                match.elapsedSeconds
              )}
            </p>

            <button
              type="button"
              onClick={() => toggleTimer(index)}
            >
              {match.timerRunning === true
                ? "⏸️ Duraklat"
                : "▶️ Devam Et"}
            </button>
          </div>
        )}

        <div
          style={{
            marginTop: "15px",
          }}
        >
          <input
            type="number"
            min="0"
            step="1"
            placeholder={match.home}
            value={
              scores[index]?.home ??
              ""
            }
            onChange={(event) =>
              updateScore(
                index,
                "home",
                event.target.value
              )
            }
          />

          {" - "}

          <input
            type="number"
            min="0"
            step="1"
            placeholder={match.away}
            value={
              scores[index]?.away ??
              ""
            }
            onChange={(event) =>
              updateScore(
                index,
                "away",
                event.target.value
              )
            }
          />
        </div>

        {renderGoalSelectors(
          match,
          index,
          "home"
        )}

        {renderGoalSelectors(
          match,
          index,
          "away"
        )}

        {scores[index]?.home !== "" &&
          scores[index]?.home !==
            undefined &&
          scores[index]?.away !== "" &&
          scores[index]?.away !==
            undefined && (
            <div
              style={{
                display: "flex",
                gap: "10px",
                flexWrap: "wrap",
                marginTop: "15px",
              }}
            >
              <button
                type="button"
                onClick={() => {
                  console.log("GOLCÜLERİ KAYDET BUTONU BASILDI", index);
                  saveMatch(index, false);
                }}
              >
                💾 Golcüleri Kaydet
              </button>

              {match.live === true && (match.matchPhase || "waiting") !== "waiting" && (
                <button
                  type="button"
                  style={{
                    background: "#b91c1c",
                    color: "white",
                  }}
                  onClick={() =>
                    saveMatch(index, true)
                  }
                >
                  🏁 Maçı Bitir
                </button>
              )}
            </div>
          )}

        {match.played === true &&
          match.homeScore !==
            undefined &&
          match.homeScore !== null &&
          match.awayScore !==
            undefined &&
          match.awayScore !==
            null && (
            <p>
              <b>
                Kayıtlı sonuç:{" "}
                {match.home}{" "}
                {match.homeScore} -{" "}
                {match.awayScore}{" "}
                {match.away}
              </b>
            </p>
          )}
      </li>
    );
  }

  return (
    <div className="card">
      <h2>📅 Lig Fikstürü</h2>

      <p>
        Fikstür haftalara otomatik ayrılır ve aynı takım aynı fikstür haftasında
        yalnızca 1 maç oynar. Gün ve saatleri siz belirlersiniz. Maç ertelenirse
        tarihini değiştirebilirsiniz; fikstür haftası değişmez.
      </p>

      {fixtures.some((match) => match?.isKnockout !== true) && (
        <div style={{ margin: "14px 0 18px", padding: "14px", border: "2px solid #d4af37", borderRadius: "12px" }}>
          <b>🔒 Mevcut fikstürü koruyan haftalık plan</b>
          <p style={{ margin: "8px 0 12px" }}>
            Eşleşmeler silinmez veya yeniden çekilmez. Yalnızca hafta numarası düzenlenir;
            her takım haftada en fazla 1 maç oynar. Haftalık dağılım mevcut fikstür korunarak yapılır.
          </p>
          <button type="button" onClick={arrangeEightMatchesPerWeek}>
            🗓️ 8 MAÇ / HAFTA DÜZENİNİ UYGULA
          </button>
        </div>
      )}

      <p>
        Skoru girdikten sonra her gol
        için kadrodan gol atan oyuncuyu
        seçin. Gol Krallığı otomatik
        hesaplanacaktır.
      </p>

      <div className="fixture-tabs">
        <button
          type="button"
          className={fixtureTab === "upcoming" ? "active" : ""}
          onClick={() => setFixtureTab("upcoming")}
        >
          🟢 Oynanacak Maçlar ({fixtures.filter((match) => match.played !== true).length})
        </button>
        <button
          type="button"
          className={fixtureTab === "completed" ? "active" : ""}
          onClick={() => setFixtureTab("completed")}
        >
          🏁 Tamamlanan Maçlar ({fixtures.filter((match) => match.played === true).length})
        </button>
      </div>

      {fixtureTab === "completed" ? (
        <CompletedMatches fixtures={fixtures} setFixtures={setFixtures} />
      ) : fixtures.length === 0 ? (
        <p>
          Henüz fikstür
          oluşturulmadı.
        </p>
      ) : (
        <section style={{ marginBottom: "30px" }}>
          <h3
            style={{
              borderBottom: "2px solid #777",
              paddingBottom: "10px",
            }}
          >
            📅 Oynanacak Maçlar • {sortedUpcomingFixtures.length} Maç
          </h3>

          {upcomingByWeek.map(({ week, matches, bayTeams }) => (
            <div key={week} style={{ marginBottom: "26px" }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: "12px",
                  flexWrap: "wrap",
                  margin: "14px 0 10px",
                  padding: "10px 12px",
                  borderRadius: "10px",
                  border: "1px solid rgba(212,175,55,0.55)",
                  background: "rgba(212,175,55,0.08)",
                }}
              >
                <b>📅 {week}. HAFTA</b>
                {bayTeams.length > 0 && (
                  <b style={{ color: "#d4af37" }}>
                    BAY: {bayTeams.join(", ")}
                  </b>
                )}
              </div>

              <ul
                className="teamList"
                style={{
                  padding: 0,
                  listStyle: "none",
                }}
              >
                {matches.map(({ match, index }) => renderMatch(match, index))}
              </ul>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}